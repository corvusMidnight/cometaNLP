# Changelog

## v0.0.3a

- Added documentation (Google Style) for the source code
- Added badges and information to package README.md 

## v0.0.4

- Fixed documentation for the source code
- Added badges and information to package README.md 

## v0.0.5

- Fixed documentation for the source code and README.md
- Added information to package README.md 