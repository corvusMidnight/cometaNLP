# Changelog

## v0.0.3a

- Added documentation (Google Style) for the source code
- Added badges and information to package README.md 

## v0.0.4

- Fixed documentation for the source code
- Added badges and information to package README.md 

## v0.0.5

- Fixed documentation for the source code and README.md
- Added information to package README.md 

## v0.0.6

- Fixed an error which caused users who did not have spacy language models installed to run into an error
- Corrected typos in README.md

## v0.0.7

- Fixed an error which causes users who did not have nltk's "punkt" module downaloaded to run into a lookupError