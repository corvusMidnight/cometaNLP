# COMETA
Comments Extraction and Text Analysis:
An NLP data and text analysis tool for Italian, Dutch, and English social media comments.
