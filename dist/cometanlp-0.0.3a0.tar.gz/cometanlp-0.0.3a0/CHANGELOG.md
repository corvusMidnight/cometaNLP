# Changelog

## v0.0.3a

- Added documentation (Google Style) for the source code
- Added badges and information to package README.md 